document.addEventListener("DOMContentLoaded", function () {
  const search = document.getElementById("bookSearch");
  const category = document.getElementById("categoryFilter");
  const status = document.getElementById("statusFilter");
  const table = document.querySelector(".admin-table");

  function filterBooks() {
    if (!table) return;
    const rows = Array.from(table.querySelectorAll("tr")).slice(1);
    const q = (search.value || "").trim().toLowerCase();
    const cat = category.value;
    const stat = status.value;

    rows.forEach(function(row) {
      const cells = row.querySelectorAll("td");
      if (cells.length < 8) return;

      const bookText = cells[1].textContent.toLowerCase();
      const authorText = cells[2].textContent.toLowerCase();
      const isbnText = cells[1].textContent.toLowerCase();
      const rowCategory = cells[3].textContent.trim();
      const rowStatus = cells[6].textContent.trim();

      const matchesSearch = !q || bookText.includes(q) || authorText.includes(q) || isbnText.includes(q);
      const matchesCategory = !cat || rowCategory === cat;
      const matchesStatus = !stat || rowStatus === stat;

      row.style.display = (matchesSearch && matchesCategory && matchesStatus) ? "" : "none";
    });
  }

  [search, category, status].forEach(function(control) {
    if (control) {
      control.addEventListener("input", filterBooks);
      control.addEventListener("change", filterBooks);
    }
  });

  // Keep filtering working when Add New Book adds a row.
  const originalAddRow = window.addRow;
  filterBooks();
});
