document.addEventListener("DOMContentLoaded", function () {
  const confirmBtn = document.getElementById("confirmPayBtn");
  const paymentSection = document.getElementById("paymentSection");
  const paymentRadios = document.querySelectorAll('input[name="payment"]');
  const payButtons = document.querySelectorAll(".method-pay-btn[data-method]");

  if (confirmBtn && paymentSection) {
    confirmBtn.addEventListener("click", function () {
      paymentSection.classList.remove("payment-section-hidden");
      paymentSection.classList.add("payment-section-visible");
      confirmBtn.textContent = "Payment Methods Opened";
      confirmBtn.disabled = true;
      paymentSection.scrollIntoView({behavior:"smooth", block:"start"});
    });
  }

  paymentRadios.forEach(function (radio) {
    radio.addEventListener("change", function () {
      document.querySelectorAll(".payment-result-box").forEach(function (box) {
        box.classList.remove("result-visible");
      });
    });
  });

  payButtons.forEach(function (button) {
    button.addEventListener("click", function () {
      const method = button.getAttribute("data-method");
      if (method === "upi") {
        document.getElementById("upiPayBox").classList.add("result-visible");
      } else if (method === "card") {
        document.getElementById("cardPayBox").classList.add("result-visible");
        document.getElementById("cardName").focus();
      }
    });
  });

  const cardConfirmBtn = document.getElementById("cardConfirmBtn");
  if (cardConfirmBtn) {
    cardConfirmBtn.addEventListener("click", function () {
      const name = document.getElementById("cardName").value.trim();
      const number = document.getElementById("cardNumber").value.replace(/\s/g, "");
      const expiry = document.getElementById("cardExpiry").value.trim();
      const cvv = document.getElementById("cardCvv").value.trim();

      if (!name || number.length < 12 || !expiry || cvv.length < 3) {
        alert("Please enter valid card details.");
        return;
      }
      window.location.href = "order-success.html";
    });
  }
});
