document.addEventListener("DOMContentLoaded", function () {
  const modal = document.getElementById("bookModal");
  const openBtn = document.getElementById("addBookBtn");
  const closeBtn = document.getElementById("closeBookModal");
  const cancelBtn = document.getElementById("cancelBookBtn");
  const form = document.getElementById("addBookForm");
  const photo = document.getElementById("newBookPhoto");
  const preview = document.getElementById("bookPreview");
  const table = document.querySelector(".admin-table");

  function openModal() {
    modal.classList.add("show");
    document.getElementById("newBookName").focus();
  }
  function closeModal() {
    modal.classList.remove("show");
    form.reset();
    preview.innerHTML = "Book photo preview";
  }

  openBtn.addEventListener("click", openModal);
  closeBtn.addEventListener("click", closeModal);
  cancelBtn.addEventListener("click", closeModal);
  modal.addEventListener("click", function(e) {
    if (e.target === modal) closeModal();
  });

  photo.addEventListener("change", function () {
    const file = photo.files[0];
    if (!file) {
      preview.innerHTML = "Book photo preview";
      return;
    }
    const reader = new FileReader();
    reader.onload = function(e) {
      preview.innerHTML = '<img src="' + e.target.result + '" alt="Book preview">';
    };
    reader.readAsDataURL(file);
  });

  function addRow(book) {
    const row = table.insertRow(-1);
    const rowNumber = table.rows.length - 1;
    const status = Number(book.stock) === 0 ? "Out of Stock" : Number(book.stock) < 5 ? "Low Stock" : "Active";
    const statusClass = Number(book.stock) === 0 ? "bad" : Number(book.stock) < 5 ? "warn" : "";
    row.innerHTML =
      '<td>' + rowNumber + '</td>' +
      '<td><b>' + escapeHtml(book.name) + '</b><br><small>ISBN: ' + escapeHtml(book.isbn) + '</small></td>' +
      '<td>' + escapeHtml(book.author) + '</td>' +
      '<td>' + escapeHtml(book.category) + '</td>' +
      '<td>₹ ' + Number(book.price).toLocaleString("en-IN") + '</td>' +
      '<td>' + Number(book.stock) + '</td>' +
      '<td><span class="status ' + statusClass + '">' + status + '</span></td>' +
      '<td>◉　✎　♙</td>';
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, function(c) {
      return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'})[c];
    });
  }

  form.addEventListener("submit", function(e) {
    e.preventDefault();
    const book = {
      name: document.getElementById("newBookName").value.trim(),
      author: document.getElementById("newBookAuthor").value.trim(),
      category: document.getElementById("newBookCategory").value,
      price: document.getElementById("newBookPrice").value,
      stock: document.getElementById("newBookStock").value,
      isbn: document.getElementById("newBookIsbn").value.trim()
    };

    if (!book.name || !book.author || !book.category || !book.price || book.stock === "" || !book.isbn) return;

    const saved = JSON.parse(localStorage.getItem("booknestAddedBooks") || "[]");
    saved.push(book);
    localStorage.setItem("booknestAddedBooks", JSON.stringify(saved));
    addRow(book);
    closeModal();
    alert("Book added successfully!");
  });

  // Restore books added previously in this browser.
  const saved = JSON.parse(localStorage.getItem("booknestAddedBooks") || "[]");
  saved.forEach(addRow);
});
