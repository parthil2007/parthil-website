document.addEventListener("DOMContentLoaded", function () {
  const emailInput = document.getElementById("ownerEmail");
  const passwordInput = document.getElementById("ownerPassword");
  const loginBtn = document.getElementById("ownerLoginBtn");
  const message = document.getElementById("loginMessage");

  function showMessage(text, success) {
    message.textContent = text;
    message.style.display = "block";
    message.className = success ? "login-message success" : "login-message error";
  }

  function loginOwner() {
    const email = emailInput.value.trim();
    const password = passwordInput.value;

    // Demo owner credentials supplied for this website.
    if (email === "mehtaparthil25@gmail.com" && password === "20452007#pm") {
      sessionStorage.setItem("booknestOwnerLoggedIn", "true");
      showMessage("Login successful! Opening Owner Dashboard...", true);
      setTimeout(function () {
        window.location.href = "admin-dashboard.html";
      }, 350);
    } else {
      showMessage("Invalid Owner email or password.", false);
      passwordInput.focus();
    }
  }

  loginBtn.addEventListener("click", loginOwner);
  passwordInput.addEventListener("keydown", function (event) {
    if (event.key === "Enter") loginOwner();
  });
  emailInput.addEventListener("keydown", function (event) {
    if (event.key === "Enter") loginOwner();
  });
});
