// BookNest Registration Form - JavaScript Validation
// Five validations: required fields, password length, email pattern,
// strong password pattern, and 10-digit Indian mobile number pattern.

document.addEventListener("DOMContentLoaded", function () {
  const forms = document.querySelectorAll(".registration-form");

  forms.forEach(function (form) {
    form.addEventListener("submit", function (event) {
      event.preventDefault();

      const name = form.elements.name;
      const email = form.elements.email;
      const phone = form.elements.phone;
      const password = form.elements.password;
      const message = form.querySelector(".form-message");
      const fields = [name, email, phone, password];
      let valid = true;

      // Clear previous validation messages.
      fields.forEach(function (field) {
        field.nextElementSibling.textContent = "";
        field.style.borderColor = "";
      });
      message.textContent = "";
      message.style.color = "";

      function showError(field, text) {
        field.nextElementSibling.textContent = text;
        field.style.borderColor = "#c0392b";
        valid = false;
      }

      // 1. Required field validation.
      fields.forEach(function (field) {
        if (field.value.trim() === "") {
          showError(field, "This field is required.");
        }
      });

      // 2. Email pattern validation.
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
      if (email.value.trim() !== "" && !emailPattern.test(email.value.trim())) {
        showError(email, "Enter a valid email address.");
      }

      // 3. Password minimum length validation.
      if (password.value !== "" && password.value.length < 8) {
        showError(password, "Password must contain at least 8 characters.");
      }

      // 4. Password strength/pattern validation.
      const passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]).{8,}$/;
      if (password.value !== "" && !passwordPattern.test(password.value)) {
        showError(password, "Use uppercase, lowercase, number and special character.");
      }

      // 5. Indian mobile number pattern validation.
      const phonePattern = /^[6-9]\d{9}$/;
      if (phone.value.trim() !== "" && !phonePattern.test(phone.value.trim())) {
        showError(phone, "Enter a valid 10-digit Indian mobile number.");
      }

      if (valid) {
        message.textContent = "Validation successful! Registration form is valid.";
        message.style.color = "#25855a";
        form.reset();
      } else {
        message.textContent = "Please correct the highlighted fields.";
        message.style.color = "#c0392b";
      }
    });
  });
});